using borrador;
using DatosEmpresa;
using ExamenDockUp;
using Microsoft.Office.Interop.Excel;
using Microsoft.Vbe.Interop;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vender_Bosquejo_2
{
    public partial class FormVender : Form
    {
        private int n = -1;
        private int NumeroDeFacturas = -1;
        private double _precioBase = 0;
        private double _precioFinal = 0;
        private double _porcentaje = 0;
        private long _cantidadSeleccionada = 0;
        private List<Cliente> _clientes = new List<Cliente>();
        private List<Factura> _Facturas = new List<Factura>();
        private List<Productos> _compras = new List<Productos>(); //Carrito del Comprador
        private List<Productos> _productosDisponibles = new List<Productos>(); //Productos disponibles
        private List<Productos> _productosListaOriginal = new List<Productos>(); //Todos los productos, contando hasta los ya "Eliminados"
        private List<string> _datosEmpresa = new List<string>();
        private Usuario _vendedor = new Usuario();
        private FormFactura Factura = new FormFactura();
        private FormAgregarProducto ListaDeProductos = new FormAgregarProducto();
        private FormAgregarCliente AgregarCliente = new FormAgregarCliente();
        private string _pathFacturas = "";
        private string _pathClientes = "";
        private string _pathProductos = "";
        public FormVender()
        {
            InitializeComponent();
            Location = new System.Drawing.Point(0, Screen.PrimaryScreen.WorkingArea.Height - Height);
        }
        public List<string> DatosEmpresa { get { return _datosEmpresa; } set { _datosEmpresa = value; } }
        public List<Productos> Productos { get { return _productosListaOriginal; } set { _productosListaOriginal = value; } }
        public List<Cliente> Clientes { get { return _clientes; } set { _clientes = value; } }
        public Usuario Vendedor { get { return _vendedor; } set { _vendedor = value; } }
        public string PathClientes { get { return _pathClientes; } set { _pathClientes = value; } }
        public string PathFacturas { get { return _pathFacturas; } set { _pathFacturas = value; } }
        public string PathProductos { get { return _pathProductos; } set { _pathProductos = value; } }
        private void LeerListaDeFacturas()
        {
            try { _Facturas = JsonConvert.DeserializeObject<List<Factura>>(File.ReadAllText(_pathFacturas)); }
            catch { }
        }
        private void ConectarInformacion()
        {
            ListaDeProductos.Productos = ListaProductosDisponibles();
            ListaDeProductos.ComprasCliente = _compras;
            ListaDeProductos.CantidadSeleccionada = _cantidadSeleccionada;
            ListaDeProductos.DataGrid = dtgvPreview;
            ListaDeProductos.PrecioBase = _precioBase;
            ListaDeProductos.PrecioFinal = _precioFinal;
            ListaDeProductos.lblPrecioBase = lblBase;
            ListaDeProductos.lblPrecioFinal = lblPrecioFinal;

            Factura.Vendedor = _vendedor;
            Factura.ProductosOriginales = _productosListaOriginal;
            Factura.ProductosDisponibles = _productosDisponibles;
            Factura.Compras = _compras;
            Factura.Path = _pathFacturas;
            Factura.DatosEmpresa = _datosEmpresa;
            Factura.CBClientes = cbBoxClientes;
            Factura.DataPreview = dtgvPreview;
            Factura.PathProductos = _pathProductos;
            Factura.Facturas = _Facturas;

            AgregarCliente.ListaClientes = _clientes;
            AgregarCliente.PathClientes = _pathClientes;
        }
        private List<Productos> ListaProductosDisponibles()
        {
            _productosDisponibles.Clear();

            for (int i = 0; i < _productosListaOriginal.Count; i++)
            {
                if (_productosListaOriginal[i].Disponible == true)
                {
                    _productosDisponibles.Add(_productosListaOriginal[i]);
                    //_productosDisponibles.Add(new Productos(productos[i]._codigo, productos[i]._nombre, productos[i]._descripcion, productos[i]._cantidad, productos[i]._precio));
                }
            }

            return _productosDisponibles;
        }
        private void ReiniciarDatosCliente()
        {
            LlenarComboBoxClientes();
            cbBoxClientes.SelectedIndex = -1;
            cbBoxClientes.Text = "Seleccionar";
            lblDatosCliente.Text = "No Seleccionado";
        }
        private void ReiniciarPrecios()
        {
            _precioBase = 0;
            _precioFinal = 0;
            lblBase.Text = _precioBase.ToString();
            lblPrecioFinal.Text = _precioFinal.ToString();
        }
        private void LlenarComboBoxClientes()
        {
            cbBoxClientes.Items.Clear();
            for(int i=0; i<_clientes.Count; i++)
            {
                cbBoxClientes.Items.Add(_clientes[i].Identificacion());
            }
        }
        private void CantidadesSeleccionadas()
        {
            for(int i = 0; i < ListaDeProductos.ComprasCliente.Count; i++)
            {
                _compras[i].Cantidad = ListaDeProductos.ComprasCliente[i].Cantidad;
            }
        }
        private void btnListaProductos_Click(object sender, EventArgs e)
        { 
            ListaDeProductos.ShowDialog();
            //SumarColumnas();
            CantidadesSeleccionadas();
            SumarFila();
            CalcularIva();
        }       
        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            int RespaldoCantidadDeClientes = _clientes.Count;
            AgregarCliente.ShowDialog();

            if(RespaldoCantidadDeClientes != _clientes.Count)
            {
                LlenarComboBoxClientes();
                cbBoxClientes.SelectedIndex = _clientes.Count - 1;
                lblDatosCliente.Text = _clientes[cbBoxClientes.SelectedIndex].Identificacion();
            }
        }
        private void FormVenderV2_Load(object sender, EventArgs e)
        {
            LeerListaDeFacturas();
            ConectarInformacion();
            n = -1;
            NumeroDeFacturas = _Facturas.Count;

            lblVendedor.Text = $"{_vendedor.Nombre} {_vendedor.Apellido}";
            lblFechaActual.Text = $"{ DateTime.Now.Day}/{ DateTime.Now.Month}/{ DateTime.Now.Year}";            
            lblBase.Text = _precioBase.ToString();
            lblPrecioFinal.Text = _precioFinal.ToString();
            lblPosicion.Visible = false;

            _compras.Clear();
            dtgvPreview.Rows.Clear();

            ReiniciarDatosCliente();
            ReiniciarPrecios();
        }
        private void SumarFila()
        {
            _precioBase = 0;
            foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                _precioBase += Convert.ToDouble(row.Cells["PrecioTotal"].Value);                
            }
            lblBase.Text = Convert.ToString(_precioBase);
        }

       /* private void SumarColumnas()
        {           
                foreach (DataGridViewRow row in dtgvPreview.Rows)
                {
                    row.Cells["PrecioTotal"].Value = Convert.ToDouble(row.Cells["Precio"].Value) * Convert.ToDouble(row.Cells["Cantidad"].Value);
                //MessageBox.Show($"{row.Cells["PrecioTotal"].Value}");
                }                           
        }*/
        private void CalcularIva()
        {           
            _porcentaje = (_precioBase * 16)/100;
            _precioFinal = _porcentaje + _precioBase;
            lblPrecioFinal.Text = Convert.ToString(_precioFinal);                        
        }
        private int ProductoCorrespondiente()
        {
            int Posicion = -1;

            for (int i = 0; i < _productosDisponibles.Count; i++)
            {
                if (dtgvPreview[0, n].Value.ToString() == _productosDisponibles[i].Codigo)
                {
                    Posicion = i;
                    break;
                }
            }
            return Posicion;
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (n != -1 && dtgvPreview.Rows.Count > 0)
                {
                    _productosDisponibles[ProductoCorrespondiente()].Cantidad += _compras[n].Cantidad;
                    dtgvPreview.Rows.RemoveAt(n);
                    _compras.RemoveAt(n);
                    SumarFila();
                    CalcularIva();
                    if (n > -1)
                    {
                        n--;
                        lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {n + 1}";
                    }
                    if (n + 1 == 0) lblPosicion.Visible = false;
                }
                else if (n == -1)
                {
                    throw new Exception("No se ha Seleccionado Ningun Producto a Eliminar");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

            //Borrar el precio del producto al borrar el producto
            /*foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                PrecioBase -= Convert.ToDouble(row.Cells["PrecioTotal"].Value);
            }*/
            //lblBase.Text = Convert.ToString(_precioBase);

            /*foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                PrecioFinal -= Convert.ToDouble(row.Cells["PrecioTotal"].Value);
            }*/
            //lblPrecioFinal.Text = Convert.ToString(_precioFinal);
        }
        private void dtgvPreview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            lblPosicion.Visible = true;
            lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {e.RowIndex + 1}";
        }
        private void btnFacturar_Click_1(object sender, EventArgs e)
        {
            if (_compras.Count > 0)
            {
                if (_datosEmpresa.Count != 0)
                {
                    if(cbBoxClientes.SelectedIndex != -1)
                    {
                        if (DialogResult.Yes == MessageBox.Show("El Cliente es un Contribuidor Especial?", "Retenciones", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
                        {
                            Factura.Retencion = 75;
                        }
                        else Factura.Retencion = 0;
                        Factura.Impuesto = _porcentaje;
                        Factura.SubTotal = _precioBase;
                        Factura.Total = _precioFinal;
                        Factura.Cliente = _clientes[cbBoxClientes.SelectedIndex];
                        Factura.ShowDialog();
                    }
                    else MessageBox.Show("No se ha Seleccionado al Cliente a Facturar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("No se han definido los Datos de la Empresa", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("No se ha Seleccionado producto Alguno a Vender", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void cbBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbBoxClientes.SelectedIndex != -1)
            {
                lblDatosCliente.Text = _clientes[cbBoxClientes.SelectedIndex].Identificacion();
            }
            else
            {
                lblDatosCliente.Text = "No Seleccionado";
            }
        }

        private void lblRegresar_Click(object sender, EventArgs e)
        {
            this.Close();            
        }

        private void FormVender_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(NumeroDeFacturas == _Facturas.Count)
            {
                for(int i=0; i<_productosDisponibles.Count; i++)
                {
                    for(int j=0; j<_compras.Count; j++)
                    {
                        if (_compras[j].Codigo == _productosDisponibles[i].Codigo)
                        {
                            _productosDisponibles[i].Cantidad += _compras[j].Cantidad;
                        }
                    }
                }
            }
        }
    }
}