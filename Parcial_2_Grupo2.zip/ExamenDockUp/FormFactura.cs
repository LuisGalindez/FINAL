﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ExamenDockUp
{
    public partial class FormFactura : Form
    {
        private string _path = "";
        private string _pathProductos = "";
        private double _subtotal = 0;
        private double _impuesto = 0;
        private int _retencion = 0;
        private double _total = 0;
        private string _codigo = "";
        private Usuario _vendedor = new Usuario();
        private List<Productos> _productosDisponibles = new List<Productos>();
        private List<Productos> _productosListaOriginal = new List<Productos>();
        private List<Productos> _compras = new List<Productos>();
        private List<Factura> _facturas = new List<Factura>();
        private List<string> _datosEmpresa = new List<string>();
        private Cliente _cliente = new Cliente();
        private DataGridView _dataPreview = new DataGridView();
        private ComboBox _cbClientes = new ComboBox();
        public FormFactura()
        {
            InitializeComponent();
        }
        public double Impuesto { get { return _impuesto; } set { _impuesto = value; } }
        public int Retencion { get { return _retencion; } set { _retencion = value; } }
        public double Total { get { return _total; } set { _total = value; } }
        public double SubTotal { get { return _subtotal; } set { _subtotal = value; } }
        public List<Factura> Facturas { get { return _facturas; } set { _facturas = value; } }
        public List<Productos> ProductosOriginales { get { return _productosListaOriginal; } set { _productosListaOriginal = value; } }
        public List<Productos> ProductosDisponibles { get { return _productosDisponibles; } set { _productosDisponibles = value; } }
        public Cliente Cliente { get { return _cliente; } set { _cliente = value; } }
        public List<string> DatosEmpresa { get { return _datosEmpresa; } set { _datosEmpresa = value; } }
        public Usuario Vendedor { get { return _vendedor; } set { _vendedor = value; } }
        public List<Productos> Compras { get { return _compras; } set { _compras = value; } }
        public string PathProductos { get { return _pathProductos; } set { _pathProductos = value; } }
        public string Path { get { return _path; } set { _path = value; } }
        public DataGridView DataPreview { get { return _dataPreview; } set { _dataPreview = value; } }
        public ComboBox CBClientes { get { return _cbClientes; } set { _cbClientes = value; } }
        private void GuardarFactura()
        {
            string jsonFacturas = JsonConvert.SerializeObject(_facturas.ToArray(), Formatting.Indented);
            File.WriteAllText(_path, jsonFacturas);
        }
        private void GuardarProductos()
        {
            string jsonProductos = JsonConvert.SerializeObject(_productosListaOriginal.ToArray(), Formatting.Indented);
            File.WriteAllText(_pathProductos, jsonProductos);
        }
        
        /*private void DescontarInventario()
        {
            for(int i=0; i<_productosDisponibles.Count; i++)
            {
                for(int j=0; j<_compras.Count; j++)
                {
                    if (_compras[j].Codigo == _productosDisponibles[i].Codigo)
                    {
                        _productosDisponibles[i].Cantidad -= _compras[j].Cantidad;
                    }
                }
            }
        }*/
        private void LlenarDatosDeFactura()
        {
            _codigo = ((_facturas.Count + 1).ToString()).PadLeft(5, '0');
            lblNumeroFactura.Text = $"Numero de Factura  {_codigo}";
            lblFecha.Text = $"Fecha de Emision:  {DateTime.Now.Day}/{DateTime.Now.Month}/{DateTime.Now.Year}  {DateTime.Now.ToString("hh:mm:ss tt")}";

            lblNombreEmpresa.Text = DatosEmpresa[0];
            lblCorreoElectronico.Text = $"Correo Electronico: {DatosEmpresa[1]}";
            lblRif.Text = $"Rif: {DatosEmpresa[2]}";
            rtbDireccionEmpresa.Text = $"Direccion: {DatosEmpresa[3]}";

            lblNombreVendedor.Text = $"Vendedor: {_vendedor.Nombre} {_vendedor.Apellido}";
            lblCedulaVendedor.Text = $"Cedula Vendedor: {_vendedor.Cedula}";
            lblNombreComprador.Text = $"Comprador: {_cliente.Nombre} {_cliente.Apellido}";
            lblCedulaComprador.Text = $"Cedula Comprador: {_cliente.Cedula}";
            lblTelefonoComprador.Text = $"Numero de Contacto: {_cliente.NumeroDeTlf}";
        }
        private void LlenarTablaDeCompras()
        {
            dgvProductos.Rows.Clear();
            dgvImpuestos.Rows.Clear();
            dgvProductos.Rows.Add(_compras.Count);
            dgvImpuestos.Rows.Add(4);
            for (int i = 0; i < dgvProductos.Rows.Count; i++)
            {
                for (int j = 0; j < dgvProductos.Columns.Count; j++)
                {
                    if (j == 0) dgvProductos[j, i].Value = _compras[i].Cantidad;
                    else if (j == 1) dgvProductos[j, i].Value = _compras[i].Nombre;
                    else if (j == 2) dgvProductos[j, i].Value = _compras[i].Precio;
                    else if (j == 3) dgvProductos[j, i].Value = _compras[i].Precio * _compras[i].Cantidad;
                }
            }
            dgvImpuestos[0, 0].Value = "SubTotal:";
            dgvImpuestos[0, 1].Value = "Iva 16%:";
            dgvImpuestos[0, 2].Value = $"Retencion {_retencion}%:";
            dgvImpuestos[0, 3].Value = "Total";
            dgvImpuestos[1, 0].Value = _subtotal;
            dgvImpuestos[1, 1].Value = _impuesto;
            dgvImpuestos[1, 2].Value = (_impuesto * _retencion) / 100;
            if (Convert.ToInt32(dgvImpuestos[1, 2].Value) == 0) dgvImpuestos[1, 3].Value = _total;
            else dgvImpuestos[1, 3].Value = _total - Convert.ToInt32(dgvImpuestos[1, 2].Value);
        }
        private void FormFactura_Load(object sender, EventArgs e)
        {
            //LeerListaDeFacturas();
            LlenarDatosDeFactura();
            LlenarTablaDeCompras();
            dgvTotalImpuestos();
        }
        private void dgvTotalImpuestos()
        {
            if (dgvImpuestos.Rows.Count == 0)
            {
                dgvImpuestos.Rows.Add(3);
                dgvImpuestos.Rows[0].Cells[0].Value = "SubTotal";
                dgvImpuestos.Rows[1].Cells[0].Value = "Iva 16%";
                dgvImpuestos.Rows[2].Cells[0].Value = "Monto Total";
            }
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            List<string> _datosVendedor = new List<string>
            {
                _vendedor.Nombre,
                _vendedor.Apellido,
                _vendedor.Cedula
            };

            _facturas.Add(new Factura(lblFecha.Text, _datosEmpresa, _codigo, _compras, _cliente, _datosVendedor, _total, _impuesto));
            GuardarFactura();
            _compras.Clear();
            _dataPreview.Rows.Clear();
            _cbClientes.SelectedIndex = -1;
            _cbClientes.Text = "Seleccionar";
            GuardarProductos();
            this.Close();
        }
    }
}
