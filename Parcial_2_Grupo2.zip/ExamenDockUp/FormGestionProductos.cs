﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//importante
using ExamenDockUp;
using Newtonsoft.Json;
using Microsoft.Office.Interop.Excel;
using Vender_Bosquejo_2;
using System.Globalization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.Office.Core;
using System.CodeDom;

namespace borrador
{
    public partial class FormGestionDeProductos : Form
    {
        private string _pathProductos = "";
        private static List<Productos> productos = new List<Productos>();
        private List<Productos> _productosDisponibles = new List<Productos>();
        private int n = -1;
        private frmEditarProducto EditarProductos = new frmEditarProducto();
        public List<Productos> ListaProductos { get { return productos; } set { productos = value; } }
        public string PathProductos { get { return _pathProductos; } set { _pathProductos = value; } }
        public FormGestionDeProductos()
        {
            InitializeComponent();
        }
        private void GuardarProductos()
        {
            string jsonProductos = JsonConvert.SerializeObject(ListaProductos.ToArray(), Formatting.Indented);
            txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
            File.WriteAllText(_pathProductos, jsonProductos);
        }
        private int ContarProductosDisponibles()
        {
            int Contador = 0;
            for (int i = 0; i < productos.Count; i++)
            {
                if (productos[i].Eliminado == false)
                {
                    Contador++;
                }
            }
            return Contador;
        }
        private void ListaProductosDisponibles()
        {
            _productosDisponibles.Clear();

            for (int i = 0; i < productos.Count; i++)
            {
                if (productos[i].Eliminado == false)
                {
                    _productosDisponibles.Add(productos[i]);
                    //_productosDisponibles.Add(new Productos(productos[i]._codigo, productos[i]._nombre, productos[i]._descripcion, productos[i]._cantidad, productos[i]._precio));
                }
            }
        }
        private int BuscarProductoCorrespondiente()
        {
            int Posicion = -1;

            for (int i = 0; i < productos.Count; i++)
            {
                if (productos[i].Codigo == _productosDisponibles[n].Codigo)
                {
                    Posicion = i;
                    break;
                }
            }

            return Posicion;
        }
        private void BorrarProducto()
        {
            int Posicion = BuscarProductoCorrespondiente();
            //MessageBox.Show("Funciona");
            productos[Posicion].Eliminado = true;
            productos[Posicion].Disponible = false;
            _productosDisponibles.RemoveAt(n);
            MessageBox.Show("El Producto ha sido Eliminado Correctamente","Producto Eliminado");
        }
        private void LlenarTablaProductos()
        {
            dtgvProductos.Rows.Clear();
            if (productos.Count != 0 && ContarProductosDisponibles() != 0)
            {
                dtgvProductos.Rows.Add(ContarProductosDisponibles());
                ListaProductosDisponibles();

                for (int i = 0; i < ContarProductosDisponibles(); i++)
                {
                    for (int j = 0; j < dtgvProductos.Columns.Count; j++)
                    {
                        if (j == 0) dtgvProductos[j, i].Value = _productosDisponibles[i].Codigo;
                        else if (j == 1) dtgvProductos[j, i].Value = _productosDisponibles[i].Nombre;
                        else if (j == 2) dtgvProductos[j, i].Value = _productosDisponibles[i].Descripcion;
                        else if (j == 3) dtgvProductos[j, i].Value = _productosDisponibles[i].Precio;
                        else if (j == 4) dtgvProductos[j, i].Value = _productosDisponibles[i].Cantidad;
                        else if (j == 5) dtgvProductos[j, i].Value = _productosDisponibles[i].Disponible;
                    }
                }
            }
        }
        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                string codigo = txtCodigo.Text;
                string nombre = txtNombre.Text;
                double precio;
                string descripcion = txtDescripcion.Text;
                long cantidad = 0;

                //Precio
                if (!double.TryParse(txtPrecio.Text, out precio))
                {
                    throw new Exception("El precio introducido no es válido");
                }
                if (precio < 0)
                {
                    throw new Exception("El Precio Indicado no es valido\nNo se manejan valores negativos");
                }
                if (txtPrecio.Text == null)
                {
                    throw new Exception("El Campo del Precio esta Vacio!");
                }
                //Descripcion
                if (string.IsNullOrEmpty(descripcion))
                {
                    throw new Exception("Descripcion invalida");
                }
                //Cantidad
                if (!long.TryParse(txtCantidad.Text, out cantidad))
                {
                    throw new Exception("La cantidad introducida no es válida");
                }
                if (cantidad < 0)
                {
                    throw new Exception("La Cantidad Indicada no es valida\nNo se manejan valores negativos");
                }
                //Nombre
                if (string.IsNullOrEmpty(nombre))
                {
                    throw new Exception("El Campo del nombre esta vacio!");
                }
                #region Anterior Try Catch
                /*string codigo = txtCodigo.Text;
                string nombre = txtNombre.Text;
                double precio = Convert.ToDouble(txtPrecio.Text);
                string descripcion = txtDescripcion.Text;
                int cantidad = Convert.ToInt32(txtCantidad.Text);*/
                /*if (precio == 0)
                {
                    throw new Exception("El precio no puede ser 0");
                }
                else if (precio < 0)
                {
                    throw new Exception("El precio no puede ser negativo");
                }
                else if (txtPrecio.Text == null)
                {
                    throw new Exception("el precio no puede ser vacio");
                }
                else if (string.IsNullOrEmpty(descripcion) || txtDescripcion.Text == null)
                {
                    throw new Exception("Descripcion invalida");
                }
                else if (cantidad == 0 || cantidad < 0)
                {
                    throw new Exception("Ingrese una cantidad de productos correcta");
                }
                else if (string.IsNullOrEmpty(nombre))
                {
                    throw new Exception("El nombre del producto no puede ser vacio!");
                }*/
                #endregion
                int n = dtgvProductos.Rows.Add();
                Productos prod = new Productos(codigo, nombre, descripcion, cantidad, precio);
                productos.Add(prod);
                _productosDisponibles.Add(prod);
                //MessageBox.Show($"Agregado: {txtCodigo.Text}; {txtNombre.Text}  ; {txtDescripcion.Text}; {txtPrecio.Text}; {txtCantidad.Text}");
                txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
                dtgvProductos.Rows[n].Cells[0].Value = codigo;
                dtgvProductos.Rows[n].Cells[1].Value = nombre;
                dtgvProductos.Rows[n].Cells[2].Value = descripcion;
                dtgvProductos.Rows[n].Cells[3].Value = precio;
                dtgvProductos.Rows[n].Cells[4].Value = cantidad;
                dtgvProductos.Rows[n].Cells[5].Value = true;
                GuardarProductos();
                txtPrecio.Clear();
                txtNombre.Clear();
                txtDescripcion.Clear();
                txtCantidad.Clear();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dtgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex; //indice de la seleccion
            //MessageBox.Show($"row: {n}; count: {_productosDisponibles.Count}");
            /*if (n != -1) //condiciono la primera celda : codigo, nombre , descripcion...
            {
                lblform.Text = " ";
            }*/
            //Si la persona selecciona la columna de editar, abriremos dicha ventana
            if (e.ColumnIndex == 6)
            {
                EditarProductos.PathProductos = _pathProductos;
                EditarProductos.Index = n;
                EditarProductos.ListaProductos = _productosDisponibles;
                EditarProductos.ShowDialog();
                LlenarTablaProductos();
            }
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (n != -1 && dtgvProductos.Rows.Count >= 0)
                {                   //reglon//nos eliminala fila
                    if (MessageBox.Show($"Esta Seguro que desea Eliminar al Producto Indicado?\n\n {_productosDisponibles[n].DataEliminar()}", "Confirmacion", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        dtgvProductos.Rows.RemoveAt(n);
                        BorrarProducto();
                        LlenarTablaProductos();
                        n = 0;
                    }
                }
                else
                {
                    throw new Exception("No se pueden eliminar más artículos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            GuardarProductos();
        }
        private int EspaciosVaciosImportar(string[] Linea)
        {
            int EspaciosVacios = 0;

            for(int i=0; i<Linea.Length; i++) 
            {
                if (string.IsNullOrEmpty(Linea[i])) EspaciosVacios++;
            }

            return EspaciosVacios;
        }
        private void btnImportar_Click(object sender, EventArgs e)
        {
            DireccionImportar.Filter = "Archivos Csv (*.csv)|*.csv";
            if (DireccionImportar.ShowDialog() == DialogResult.OK)
            {
                string Direccion = DireccionImportar.FileName;
                try
                {
                    if (!File.Exists(Direccion)) //compruebo que este el documento 
                    {
                        throw new Exception("El Archivo Indicado no se ha Encontrado o no es Valido");
                    }
                    else
                    {
                        List<Productos> ProductosImportados = new List<Productos>();

                        string codigo = "";
                        string nombre = "";
                        string descripcion = "";
                        double precio = 0;
                        long cantidad = 0;

                        bool SobreEscribirDatos = false;
                        int ContadorDeFilas = 1;
                        int EspaciosVacios = 0;

                        StreamReader archivo = new StreamReader(Direccion);
                        string linea;

                        DialogResult Encabezados = MessageBox.Show("Las Columnas de Su Tabla de Productos Poseen Encabezado?\nEn caso Afirmativo se omitira la primera fila de la Tabla", "Formato de la Tabla", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                        if(DialogResult.Cancel != Encabezados)
                        {
                            if (DialogResult.Yes == Encabezados)
                            {
                                archivo.ReadLine();
                            }

                            DialogResult SobreEscribir = MessageBox.Show("Desea Sobreescribir los Datos Anteriores?\nEn caso Afirmativo se eliminaran los productos anteriores\nsiendo reemplazados por los que van a ser Importados", "Formato de Guardado", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);

                            if (DialogResult.Cancel != SobreEscribir)
                            {
                                if (DialogResult.Yes == SobreEscribir) 
                                { 
                                    SobreEscribirDatos = true; 
                                }

                                while ((linea = archivo.ReadLine()) != null)
                                {
                                    //delimita cada campo del csv

                                    string[] contenido = linea.Split(';');

                                    if (contenido.Length == 5 || contenido.Length == 4)
                                    {
                                        if (contenido.Length == 4)
                                        {
                                            if (string.IsNullOrEmpty(contenido[3]))
                                            {
                                                throw new Exception($"Falta Asignar un Precio en la fila {ContadorDeFilas}.");
                                            }
                                            else if (!double.TryParse(contenido[2], out precio))
                                            {
                                                throw new Exception($"El precio introducido en la fila {ContadorDeFilas} es Incorrecto\nPara el Manejo de Precios solo se Admiten numeros.");
                                            }
                                            else if (precio < 0)
                                            {
                                                throw new Exception($"El Precio Indicado en la fila {ContadorDeFilas} es Incorrecto\nNo se manejan valores negativos");
                                            }
                                            else if (string.IsNullOrEmpty(contenido[3]))
                                            {
                                                throw new Exception($"Falta Asignar la Cantidad en la fila {ContadorDeFilas}.");
                                            }
                                            else if (!long.TryParse(contenido[3], out cantidad))
                                            {
                                                throw new Exception($"La cantidad introducida en la fila {ContadorDeFilas} no es válida\nEl Formato de la Cantidad debe ser en numeros");
                                            }
                                            else if (cantidad < 0)
                                            {
                                                throw new Exception($"La Cantidad Indicada en la fila {ContadorDeFilas} no es valida\nNo se manejan valores negativos");
                                            }
                                            else
                                            {
                                                EspaciosVacios += EspaciosVaciosImportar(contenido);
                                                nombre = contenido[0];
                                                descripcion = contenido[1];

                                                if (SobreEscribirDatos == true) codigo = (ContadorDeFilas.ToString()).PadLeft(5, '0');
                                                else if (ProductosImportados.Count == 0) codigo = ((productos.Count + 1).ToString()).PadLeft(5, '0');
                                                else codigo = ((productos.Count + ProductosImportados.Count + 1).ToString()).PadLeft(5, '0');

                                                ProductosImportados.Add(new Productos(codigo, nombre, descripcion, cantidad, precio));
                                                ContadorDeFilas++;
                                            }
                                        }
                                        else
                                        {
                                            if (string.IsNullOrEmpty(contenido[3]))
                                            {
                                                throw new Exception($"Falta Asignar un Precio en la fila {ContadorDeFilas}.");
                                            }
                                            else if (!double.TryParse(contenido[3], out precio))
                                            {
                                                throw new Exception($"El precio introducido en la fila {ContadorDeFilas} es Incorrecto\nPara el Manejo de Precios solo se Admiten numeros.");
                                            }
                                            else if (precio < 0)
                                            {
                                                throw new Exception($"El Precio Indicado en la fila {ContadorDeFilas} es Incorrecto\nNo se manejan valores negativos");
                                            }
                                            else if (string.IsNullOrEmpty(contenido[4]))
                                            {
                                                throw new Exception($"Falta Asignar la Cantidad en la fila {ContadorDeFilas}.");
                                            }
                                            else if (!long.TryParse(contenido[4], out cantidad))
                                            {
                                                throw new Exception($"La cantidad introducida en la fila {ContadorDeFilas} no es válida\nEl Formato de la Cantidad debe ser en numeros");
                                            }
                                            else if (cantidad < 0)
                                            {
                                                throw new Exception($"La Cantidad Indicada en la fila {ContadorDeFilas} no es valida\nNo se manejan valores negativos");
                                            }
                                            else
                                            {
                                                EspaciosVacios += EspaciosVaciosImportar(contenido);
                                                nombre = contenido[1];
                                                descripcion = contenido[2];

                                                if (SobreEscribirDatos == true) codigo = (ContadorDeFilas.ToString()).PadLeft(5, '0');
                                                else if (ProductosImportados.Count == 0) codigo = ((productos.Count + 1).ToString()).PadLeft(5, '0');
                                                else codigo = ((productos.Count + ProductosImportados.Count + 1).ToString()).PadLeft(5, '0');

                                                ProductosImportados.Add(new Productos(codigo, nombre, descripcion, cantidad, precio));
                                                ContadorDeFilas++;
                                            }
                                        }
                                    }
                                    else throw new Exception("El Numero de Columnas de la Tabla no es Valido\n" +
                                        "Se Manejan unicamente tablas de 4 o 5 Columnas\n\nPara el Caso de Tablas de 4 Columnas;\n" +
                                        "Los Datos deben organizarse de la Siguiente Manera:\n\n1. Nombre - 2. Descripcion - 3. Precio - 4. Cantidad\n\n" +
                                        "Para el Caso de Tablas de 5 Columnas;\nse considera que la columna 1 corresponde a los \n" +
                                        "codigos de los Productos, por ende el orden\nde las Columnas pasa a ser el Siguiente:\n\n" +
                                        "2. Nombre - 3. Descripcion - 4. Precio - 5. Cantidad\n\nNota: Para este ultimo caso; los codigos Indicados\n" +
                                        "en la tabla a Importar no seran tomados en cuenta\npara mantener una coherencia y un buen\nfuncionamiento dentro del programa");
                                }

                                if (SobreEscribirDatos == true)
                                {
                                    productos.Clear();
                                    productos = ProductosImportados;
                                }

                                else if (SobreEscribirDatos == false)
                                {
                                    for (int i = 0; i < ProductosImportados.Count; i++)
                                    {
                                        productos.Add(ProductosImportados[i]);
                                    }
                                }

                                ////cierro el archivo
                                MessageBox.Show("Productos Importados");
                                if(EspaciosVacios==1) MessageBox.Show($"En la Tabla Importada se ha Encotrado {EspaciosVacios} Celda Vacia");
                                else MessageBox.Show($"En la Tabla Importada se han Encotrado {EspaciosVacios} Celdas Vacias");
                                archivo.Close();
                                LlenarTablaProductos();
                                GuardarProductos();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ExportarExcel(dtgvProductos);
            MessageBox.Show("Productos Exportados");
        }
        private void ExportarExcel(DataGridView dataDeProductos)
        {
            Microsoft.Office.Interop.Excel.Application Productos = new Microsoft.Office.Interop.Excel.Application();
            
            Productos.Application.Workbooks.Add(true);

            int IndiceDeColumna = 0;
            foreach (DataGridViewColumn col in dataDeProductos.Columns) //Para las columnas 
            {
                if (col.Name == "Disponible") break;
                IndiceDeColumna++;
                Productos.Cells[1, IndiceDeColumna] = col.Name;
            }

            int IndiceDeFila = 0;
            foreach (DataGridViewRow row in dataDeProductos.Rows)//Para las filas 
            {
                IndiceDeFila++;
                IndiceDeColumna = 0;

                foreach (DataGridViewColumn col in dataDeProductos.Columns) 
                {
                    if (col.Name == "Disponible") break;
                    IndiceDeColumna++;
                    Productos.Cells[IndiceDeFila + 1, IndiceDeColumna] = row.Cells[col.Name].Value;
                }
            }
            Productos.Visible = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {//using systen.io
            
            /*Con este condicional; al cargarse la ventana se escribe el codigo correspondiente al siguiente
             porducto a crear*/

            if (productos.Count == 0)
            {
                txtCodigo.Text = ("1".PadLeft(5, '0'));
            }
            else
            {
                txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
            }

            //Con este otro se crean las filas necesarias para mostrar los productos que hay
            LlenarTablaProductos();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)
            {
                if (Convert.ToBoolean(dtgvProductos[5, n].Value) == true)
                {
                    dtgvProductos[5, n].Value = false;
                    _productosDisponibles[n].Disponible = false;
                    productos[BuscarProductoCorrespondiente()].Disponible = false;
                }
                else
                {
                    dtgvProductos[5, n].Value = true;
                    _productosDisponibles[n].Disponible = true;
                    productos[BuscarProductoCorrespondiente()].Disponible = true;
                }
                GuardarProductos();
            }
        }
    }
}
